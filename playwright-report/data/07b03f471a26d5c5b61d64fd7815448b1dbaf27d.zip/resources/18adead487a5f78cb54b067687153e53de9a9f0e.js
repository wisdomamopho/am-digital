// add event listenersdocument.addEventListener("quartex_search", OnQuartexSearch, false);document.addEventListener("quartex_download", OnQuartexDownload, false);document.addEventListener("document_viewer_page_view", OnDocumentViewerPageView, false);
//event helpers
window.register_search_event = function (source, terms) {
    var searchEvent = new CustomEvent("quartex_search", {
        detail: {
            terms: terms,
            source: source
        },
        bubbles: true,
        cancelable: true
    });

    document.dispatchEvent(searchEvent);
}


window.register_download_event = function (documentTitle, noOfPages) {
    var downloadEvent = new CustomEvent("quartex_download", {
        detail: {
            documentTitle: documentTitle,
            noOfPages: noOfPages
        },
        bubbles: true,
        cancelable: true
    });

    document.dispatchEvent(downloadEvent);
}

window.register_document_viewer_page_view_event = function () {
    var documentViewerPageViewEvent = new CustomEvent("document_viewer_page_view", {
        bubbles: true,
        cancelable: true
    });
    document.dispatchEvent(documentViewerPageViewEvent);
}

//events
function OnQuartexSearch(e) {

    //log counter search
    $.ajax({
        type: "POST",
        url: '/Documents/logsearch'
    });
}

function OnQuartexDownload(e) {
    try {
        AMjs.analytics.recordPageEvent(AMjs.analytics.pageViewId, 'PDF-Download', e.detail.noOfPages);

        $.ajax({
            type: "POST",
            url: '/Documents/logdbhit/' + e.detail.documentTitle
        });

    }
    catch (ex) {
        //do nothing - AMjs not included in custom script
    }
}

function OnDocumentViewerPageView(e) {
    try {
        _paq.push(['setCustomUrl', window.location.href]);
        _paq.push(['trackPageView']);
    }
    catch (ex) {
        //do nothing - Matomo not included for Quartex customers
    }
}