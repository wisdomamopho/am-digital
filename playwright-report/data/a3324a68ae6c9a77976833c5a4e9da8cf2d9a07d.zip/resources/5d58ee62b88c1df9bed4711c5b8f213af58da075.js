function HeaderSearch(frm) {

    /////// 
    // 1 = Documents
    // 2 = Entire Site
    ///////
    //var searchOption = parseInt($('input[name=filter-menu]:checked').val());

    var position = 'toast-top-right';
    var searchOption = 1;

    if (searchOption === 2) {
        toastr.warning("Site wide search not enabled", null, { positionClass: position });
        return false;
    }

    var val = $("input[type=search]:first", $(frm)).val();

    if (val !== "") {
        if (val.length < 2) {
            toastr.error("Please enter at least three characters", null, { positionClass: position });
            return false;
        }
    }
    else {
        toastr.error("Please enter search term", null, { positionClass: position });
        return false;
    }
    
    register_search_event("HeaderSearch", val);

    console.log(AMD);
    AMD.PreviousSearchService.storeBasicSearch(val);
};

function SetupMenuFixes() {
    jfdInclude.init();

    function updateAriaExpanded(element) {
        $(element).attr('aria-expanded', function (i, attr) {
            return attr === 'true' ? 'false' : 'true'
        });
    };

    $(".carousel").css("visibility","visible");

    $(".navigation__item:not(.not-me)", ".hidden-links").on("click", function () {
        if($(this).attr("target") != null && $(this).attr("target") === "_blank")
            window.open($(this).attr("href"), '_blank');
        else
            window.location.href = $(this).attr("href");
    });

    $(".site-nav__item--with-subnav").on("click", function () {
        updateAriaExpanded($(this).children("a.navigation__item.with-children:first"));
    });

    $(".more-menu-items-btn").on("click", function () {
        updateAriaExpanded($(this));
    });

    $(".link",".advanced-search-link-in-dd-menu").off().on("click", function() {
        window.location.href = $(this).attr("href");
    });

    $(".navigation").css("visibility", "");

    $(window).resize(function() {
        $(".navigation__item:not(.not-me)", ".hidden-links").off().on("click", function () {
            window.location.href = $(this).attr("href");
        });

        $(".link",".advanced-search-link-in-dd-menu").off().on("click", function() {
            window.location.href = $(this).attr("href");
        });
    });
}

function toggleDisplay(element) {
    if (element == undefined || element == null)
        return;
    if (element.style.display === "none") {
        element.style.display = "block";
    } else {
        element.style.display = "none";
    }
}

function setupHighContrastIntroBoxes() {
    var logo = document.getElementById("am-quartex-tagline-reversed-span");
    var highContrastLogo = document.getElementById("am-quartex-tagline-reversed-high-contrast-span");
    toggleDisplay(logo);
    toggleDisplay(highContrastLogo);

    $("div.intro").each(function() {
        var styleText = $(this).attr("style");
        var styleData = $(this).data("style");

        if ((styleData == null || styleData === "") && styleText != null && styleText !== "") {
            $(this).data("style", styleText);
            $(this).removeAttr("style");
        } else if((styleText == null || styleText === "") && styleData != null && styleData !== "") {
            $(this).attr("style", styleData);
            $(this).data("style", "");
        }
    });

    $("section.section-with-carousel").each(function() {
        var styleText = $(this).attr("style");
        var styleData = $(this).data("style");

        if ((styleData == null || styleData === "") && styleText != null && styleText !== "") {
            $(this).data("style", styleText);
            $(this).removeAttr("style");
        } else if((styleText == null || styleText === "") && styleData != null && styleData !== "") {
            $(this).attr("style", styleData);
            $(this).data("style", "");
        }
    });
}

//CustomEvent Polyfill for IE11
(function () {

    if (typeof window.CustomEvent === "function") return false;

    function CustomEvent(event, params) {
        params = params || { bubbles: false, cancelable: false, detail: undefined };
        var evt = document.createEvent("CustomEvent");
        evt.initCustomEvent(event, params.bubbles, params.cancelable, params.detail);
        return evt;
    }

    CustomEvent.prototype = window.Event.prototype;

    window.CustomEvent = CustomEvent;
})();

//Polyfill for includes
if (!String.prototype.includes) {
    String.prototype.includes = function (search, start) {
        'use strict';
        if (typeof start !== 'number') {
            start = 0;
        }

        if (start + search.length > this.length) {
            return false;
        } else {
            return this.indexOf(search, start) !== -1;
        }
    };
}

//Polyfill for startsWith and endsWith
(function (sp) {

    if (!sp.startsWith)
        sp.startsWith = function (str) {
            return !!(str && this) && !this.lastIndexOf(str, 0);
        }

    if (!sp.endsWith)
        sp.endsWith = function (str) {
            var offset = str && this ? this.length - str.length : -1;
            return offset >= 0 && this.lastIndexOf(str, offset) === offset;
        }

})(String.prototype);

$(function () {
    $("#close-preview-banner-btn").on("click keydown", function(e) {
        if ((e.type === "keydown" && e.keyCode === 13) || e.type === "click") {
            $("#preview-banner").slideUp('slow');
        }
    });

    //Remove inline style for primary/secondary colour.
    $("span.primary-colour, span.secondary-colour, span.button-colour", ".mce-container").css("color", "");
    $("a", ".mce-container").each(function() {
        var href = $(this).attr("href");
        if (href != null && href.startsWith("../")) {
            href = "/" + href.replace(/..\\/g, "");
            $(this).attr("href", href);
        }
    });

    $(".js-site-head__high-contrast-toggle").on("click", function() {
        setupHighContrastIntroBoxes();
    });

    var cookieName = "active-theme=";
    var ca = document.cookie.split(';');
    for (var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) === ' ') c = c.substring(1, c.length);
        if (c.indexOf(cookieName) === 0) {
            var value = c.substring(cookieName.length, c.length);

            if (value === "high-contrast")
                setupHighContrastIntroBoxes();
        }
    }

    $(".mce-container").each(function() {
        $("a", $(this)).each(function() {
            var images = $(this).find('img');
            if (images.length && $(images[0]).attr("style") != null) {
                $(this).addClass("mce-container__anchor-with-image mce-container__anchor-with-image--custom-styling");
            } else if (images.length) {
                $(this).addClass("mce-container__anchor-with-image");
            }
        });
    });

});

function HighlightWordsAndPhrases(terms) {
    var Highlighting = new Mark('.mark-highlightable');
    Highlighting.mark(terms, { accuracy: { value: "exactly", limiters: [",", ".", "-", "\""] }, separateWordSearch: false });
    window.Highlighting = Highlighting;
}

const UrlParams = new URLSearchParams(window.location.search);

if (UrlParams.get('highlight') != null) {
    var terms = UrlParams.get('highlight').split(',');
    HighlightWordsAndPhrases(terms);
}
