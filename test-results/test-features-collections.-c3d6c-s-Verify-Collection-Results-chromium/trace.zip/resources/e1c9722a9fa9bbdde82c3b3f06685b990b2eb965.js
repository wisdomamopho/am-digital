$(function() {
    /*
     * classes
     *   a-z-lego-block - top level block class, used to constrain to block.
     *   js-a-z-btn-click - A - Z button click
     *   js-a-z-top-btn-click = Top button click
     */
    function onAZBtnClick(element) {
        var letter = $(element).data("letter");

        var block = $(element).closest(".a-z-lego-block");

        var firstLi = $("div[data-letter='" + letter + "']:first", block);

        if (firstLi !== undefined && firstLi !== null && firstLi.offset() !== undefined) {
            $('html, body').animate({ scrollTop: firstLi.offset().top }, 1000);
            $("div[data-letter='" + letter + "']:first", block)[0].children[0].focus();
        }

    }

    function onAZTopBtnClick(element) {
        var block = $(element).closest(".a-z-lego-block");
        $('html, body').animate({ scrollTop: block.offset().top }, 1000);
        $(".js-a-z-prev").focus();

    }

    //Dont need to use delegation as all items should be loaded before the event handler listener is in effect
    $(".js-a-z-btn-click").on("click", function() {
        onAZBtnClick(this);
    });

    $(".js-a-z-btn-click").on("keyup", function () {
        if (event.keyCode === 13) {
            onAZBtnClick(this);
        }

    });

    $(".js-a-z-top-btn-click").on("click", function() {
        onAZTopBtnClick(this);
    });



    $(".js-a-z-top-btn-click").on("keyup", function () {
        if (event.keyCode === 13) {
            onAZTopBtnClick(this);
        }
    });

});